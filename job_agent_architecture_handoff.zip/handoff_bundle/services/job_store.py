from __future__ import annotations

from dataclasses import asdict, is_dataclass
from typing import Any

from services.db import db_connection


JOB_COLUMNS = [
    "date_found",
    "date_last_validated",
    "company",
    "title",
    "role_family",
    "normalized_title",
    "location",
    "remote_type",
    "dallas_dfw_match",
    "company_careers_url",
    "job_posting_url",
    "ats_type",
    "requisition_id",
    "source",
    "compensation_raw",
    "compensation_status",
    "validation_status",
    "validation_confidence",
    "fit_score",
    "fit_tier",
    "ai_priority",
    "match_rationale",
    "risk_flags",
    "application_angle",
    "cover_letter_starter",
    "status",
    "duplicate_key",
    "active_status",
]


def _clean(value: Any) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    if text.lower() == "nan":
        return ""
    return text


def _to_float(value: Any):
    text = _clean(value)
    if not text:
        return None
    try:
        return float(text)
    except Exception:
        return None


def coerce_job_payload(job: Any) -> dict[str, Any]:
    if is_dataclass(job):
        raw = asdict(job)
    elif isinstance(job, dict):
        raw = dict(job)
    else:
        raise TypeError("job must be a dict or dataclass instance")

    payload: dict[str, Any] = {}
    for key in JOB_COLUMNS:
        payload[key] = raw.get(key, "")

    payload["fit_score"] = _to_float(payload.get("fit_score"))
    payload["duplicate_key"] = _clean(payload.get("duplicate_key"))
    payload["status"] = _clean(payload.get("status")) or "New"
    payload["active_status"] = _clean(payload.get("active_status")) or "Active"

    return payload


def get_existing_job_by_duplicate_key(duplicate_key: str):
    with db_connection() as conn:
        return conn.execute(
            """
            SELECT *
            FROM jobs
            WHERE duplicate_key = ?
            LIMIT 1
            """,
            (duplicate_key,),
        ).fetchone()


def is_removed_duplicate_key(duplicate_key: str) -> bool:
    if not _clean(duplicate_key):
        return False

    with db_connection() as conn:
        row = conn.execute(
            """
            SELECT 1
            FROM removed_jobs
            WHERE duplicate_key = ?
            LIMIT 1
            """,
            (duplicate_key,),
        ).fetchone()

    return row is not None


def insert_job(payload: dict[str, Any]) -> int:
    with db_connection() as conn:
        cur = conn.execute(
            """
            INSERT INTO jobs (
                date_found,
                date_last_validated,
                company,
                title,
                role_family,
                normalized_title,
                location,
                remote_type,
                dallas_dfw_match,
                company_careers_url,
                job_posting_url,
                ats_type,
                requisition_id,
                source,
                compensation_raw,
                compensation_status,
                validation_status,
                validation_confidence,
                fit_score,
                fit_tier,
                ai_priority,
                match_rationale,
                risk_flags,
                application_angle,
                cover_letter_starter,
                status,
                duplicate_key,
                active_status,
                workflow_status,
                applied_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'New', '')
            """,
            (
                payload["date_found"],
                payload["date_last_validated"],
                payload["company"],
                payload["title"],
                payload["role_family"],
                payload["normalized_title"],
                payload["location"],
                payload["remote_type"],
                payload["dallas_dfw_match"],
                payload["company_careers_url"],
                payload["job_posting_url"],
                payload["ats_type"],
                payload["requisition_id"],
                payload["source"],
                payload["compensation_raw"],
                payload["compensation_status"],
                payload["validation_status"],
                payload["validation_confidence"],
                payload["fit_score"],
                payload["fit_tier"],
                payload["ai_priority"],
                payload["match_rationale"],
                payload["risk_flags"],
                payload["application_angle"],
                payload["cover_letter_starter"],
                payload["status"],
                payload["duplicate_key"],
                payload["active_status"],
            ),
        )
        return int(cur.lastrowid)


def update_existing_job(existing_id: int, payload: dict[str, Any], preserve_applied: bool = True) -> None:
    with db_connection() as conn:
        existing = conn.execute(
            """
            SELECT workflow_status, applied_date
            FROM jobs
            WHERE id = ?
            LIMIT 1
            """,
            (existing_id,),
        ).fetchone()

        workflow_status = "New"
        applied_date = ""

        if existing is not None and preserve_applied and str(existing["workflow_status"]) == "Applied":
            workflow_status = "Applied"
            applied_date = str(existing["applied_date"] or "").strip()

        conn.execute(
            """
            UPDATE jobs
            SET
                date_last_validated = ?,
                company = ?,
                title = ?,
                role_family = ?,
                normalized_title = ?,
                location = ?,
                remote_type = ?,
                dallas_dfw_match = ?,
                company_careers_url = ?,
                job_posting_url = ?,
                ats_type = ?,
                requisition_id = ?,
                source = ?,
                compensation_raw = ?,
                compensation_status = ?,
                validation_status = ?,
                validation_confidence = ?,
                fit_score = ?,
                fit_tier = ?,
                ai_priority = ?,
                match_rationale = ?,
                risk_flags = ?,
                application_angle = ?,
                cover_letter_starter = ?,
                status = ?,
                active_status = ?,
                workflow_status = ?,
                applied_date = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (
                payload["date_last_validated"],
                payload["company"],
                payload["title"],
                payload["role_family"],
                payload["normalized_title"],
                payload["location"],
                payload["remote_type"],
                payload["dallas_dfw_match"],
                payload["company_careers_url"],
                payload["job_posting_url"],
                payload["ats_type"],
                payload["requisition_id"],
                payload["source"],
                payload["compensation_raw"],
                payload["compensation_status"],
                payload["validation_status"],
                payload["validation_confidence"],
                payload["fit_score"],
                payload["fit_tier"],
                payload["ai_priority"],
                payload["match_rationale"],
                payload["risk_flags"],
                payload["application_angle"],
                payload["cover_letter_starter"],
                payload["status"],
                payload["active_status"],
                workflow_status,
                applied_date,
                existing_id,
            ),
        )


def upsert_job(job: Any) -> dict[str, Any]:
    payload = coerce_job_payload(job)
    duplicate_key = payload["duplicate_key"]

    if duplicate_key and is_removed_duplicate_key(duplicate_key):
        return {
            "status": "skipped_removed",
            "duplicate_key": duplicate_key,
            "job_id": None,
        }

    existing = get_existing_job_by_duplicate_key(duplicate_key) if duplicate_key else None

    if existing is None:
        job_id = insert_job(payload)
        return {
            "status": "inserted",
            "duplicate_key": duplicate_key,
            "job_id": job_id,
        }

    existing_id = int(existing["id"])
    update_existing_job(existing_id, payload, preserve_applied=True)
    return {
        "status": "updated",
        "duplicate_key": duplicate_key,
        "job_id": existing_id,
    }
